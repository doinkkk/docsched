import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: {
    origin: "*"
  }
});

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'data.json');

function loadData() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (e) {
    return { patients: [], appointments: [], messages: [] };
  }
}

function saveData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

function genId(prefix='id') {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`;
}

let db = loadData();

// -------- Patients --------
app.get('/api/patients', (req, res) => {
  res.json(db.patients);
});

app.post('/api/patients', (req, res) => {
  const { name, contact='' } = req.body || {};
  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'Name is required' });
  }
  const patient = { id: genId('pt'), name: name.trim(), contact, headlineAmount: 0 };
  db.patients.push(patient);
  saveData();
  res.json(patient);
});

app.patch('/api/patients/:id', (req, res) => {
  const p = db.patients.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  const { name, contact, headlineAmount } = req.body || {};
  if (typeof name === 'string') p.name = name.trim();
  if (typeof contact === 'string') p.contact = contact;
  if (typeof headlineAmount === 'number' && !Number.isNaN(headlineAmount)) p.headlineAmount = headlineAmount;
  saveData();
  res.json(p);
});

// -------- Appointments --------
app.get('/api/appointments', (req, res) => {
  const { from, to } = req.query;
  let result = db.appointments;
  if (from) {
    const f = new Date(from).getTime();
    result = result.filter(a => new Date(a.dateTime).getTime() >= f);
  }
  if (to) {
    const t = new Date(to).getTime();
    result = result.filter(a => new Date(a.dateTime).getTime() <= t);
  }
  res.json(result);
});

app.post('/api/appointments', (req, res) => {
  const { patientId, dateTime, duration=30, notes='', fee=0 } = req.body || {};
  if (!patientId || !dateTime) return res.status(400).json({ error: 'patientId and dateTime are required' });
  const patient = db.patients.find(p => p.id === patientId);
  if (!patient) return res.status(400).json({ error: 'Invalid patientId' });
  const appt = { id: genId('apt'), patientId, dateTime, duration, notes, fee: Number(fee) || 0 };
  db.appointments.push(appt);
  saveData();
  res.json(appt);
});

app.delete('/api/appointments/:id', (req, res) => {
  const before = db.appointments.length;
  db.appointments = db.appointments.filter(a => a.id !== req.params.id);
  if (db.appointments.length === before) return res.status(404).json({ error: 'Not found' });
  saveData();
  res.json({ ok: true });
});

// -------- Messages / Chat --------
app.get('/api/messages', (req, res) => {
  const { patientId } = req.query;
  if (!patientId) return res.status(400).json({ error: 'patientId is required' });
  const messages = db.messages.filter(m => m.patientId === patientId).sort((a,b)=>a.timestamp-b.timestamp);
  res.json(messages);
});

io.on('connection', (socket) => {
  socket.on('join', ({ patientId }) => {
    if (!patientId) return;
    socket.join(`pt:${patientId}`);
  });

  socket.on('message', (msg) => {
    // msg: { patientId, sender, text }
    if (!msg || !msg.patientId || !msg.text) return;
    const exists = db.patients.some(p => p.id === msg.patientId);
    if (!exists) return;
    const message = {
      id: genId('msg'),
      patientId: msg.patientId,
      sender: msg.sender === 'patient' ? 'patient' : 'doctor',
      text: (msg.text || '').toString().slice(0, 5000),
      timestamp: Date.now()
    };
    db.messages.push(message);
    saveData();
    io.to(`pt:${message.patientId}`).emit('message', message);
  });
});

// -------- Earnings utility --------
app.get('/api/earnings/summary', (req, res) => {
  const { from, to } = req.query;
  let appts = db.appointments.slice();
  if (from) {
    const f = new Date(from).getTime();
    appts = appts.filter(a => new Date(a.dateTime).getTime() >= f);
  }
  if (to) {
    const t = new Date(to).getTime();
    appts = appts.filter(a => new Date(a.dateTime).getTime() <= t);
  }
  const totalFromAppointments = appts.reduce((sum, a) => sum + (Number(a.fee) || 0), 0);
  const headlineTotals = db.patients.reduce((sum,p)=> sum + (Number(p.headlineAmount) || 0), 0);
  const byPatient = {};
  for (const a of appts) {
    byPatient[a.patientId] = (byPatient[a.patientId] || 0) + (Number(a.fee) || 0);
  }
  res.json({
    totalFromAppointments,
    headlineTotals,
    combined: totalFromAppointments + headlineTotals,
    byPatient
  });
});

// Fallback to index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
