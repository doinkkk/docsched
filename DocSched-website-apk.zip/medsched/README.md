# DocSched — Minimal Doctor Scheduling + Chat + Earnings

A tiny, good-looking web app for a single doctor to:
- create & view appointments (with fee and notes)
- chat with each patient (real-time)
- track earnings from appointments, plus a manual "headline amount" per patient that shows in the chat header and sidebar

> Minimal by design: no auth, one doctor user, data saved to a local `data.json`.


## Quick start

1) Make sure you have Node.js (v18+ recommended).  
2) Install dependencies and start the server:

```bash
npm install
npm start
```

3) Open http://localhost:3000

## Features
- Patients sidebar with search and quick add
- "Headline amount" (₹) editable at the top bar for the selected patient. This shows as a badge next to the patient's name.
- Schedule tab: add appointments with date/time, fee, duration, and notes; see the list; delete if needed
- Chat tab: real-time Socket.IO chat per patient. (Open the app in two browser windows and select the same patient to see messages sync.)
- Earnings tab: totals from appointments, plus the sum of all headline amounts (separately), and a "combined" figure. Also shows a breakdown by patient and lets you export CSV.

## Notes
- Data is stored in `data.json` in the project root. Delete it to reset.
- This app is single-doctor and intentionally avoids auth, roles, and multi-user management for simplicity.
- For production, add proper authentication, SSL, and a real database.

Enjoy!


## Host it as a website

### Simple (Docker)
```bash
docker build -t docsched .
docker run -p 3000:3000 docsched
# open http://localhost:3000
```

### Any Node host (Render/Railway/Fly/Heroku)
- Use Node 18+
- Start command: `npm start`
- Expose port `PORT`

## Build an Android APK (Capacitor)
> Requires Android Studio + Android SDK installed.

```bash
# inside the project folder
npm install
npm run cap:init           # one-time
npm run cap:sync
npm run cap:android:add    # one-time
npm run cap:android:open   # opens Android Studio
```
In Android Studio:
- Build > Build Bundle(s) / APK(s) > Build APK(s)
- The APK will be in `android/app/build/outputs/apk/...`

The Capacitor app wraps the `public` web UI into a native app.

