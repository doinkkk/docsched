const state = {
  patients: [],
  appointments: [],
  activePatientId: null,
  socket: null,
  messages: []
};

// --------------- Helpers ---------------
function el(html) {
  const template = document.createElement('template');
  template.innerHTML = html.trim();
  return template.content.firstElementChild;
}

function rupees(n) {
  n = Number(n)||0;
  return '₹' + n.toLocaleString('en-IN', { maximumFractionDigits: 0 });
}

function formatDT(dt) {
  const d = new Date(dt);
  return d.toLocaleString();
}

// --------------- API ---------------
async function api(path, opts={}) {
  const res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function loadPatients() {
  state.patients = await api('/api/patients');
  renderPatients();
  fillApptPatientSelect();
}

async function loadAppointments() {
  state.appointments = await api('/api/appointments');
  renderAppointments();
  if (document.querySelector('#view-earnings') && !document.querySelector('#view-earnings').classList.contains('hidden')) {
    loadEarnings();
  }
}

async function loadMessages(patientId) {
  state.messages = await api(`/api/messages?patientId=${encodeURIComponent(patientId)}`);
  renderMessages();
}

// --------------- Patients sidebar ---------------
const patientList = document.getElementById('patientList');
const patientSearch = document.getElementById('patientSearch');
const addPatientForm = document.getElementById('addPatientForm');
const newPatientName = document.getElementById('newPatientName');

function renderPatients() {
  const q = (patientSearch.value || '').toLowerCase();
  const items = state.patients
    .filter(p => p.name.toLowerCase().includes(q))
    .sort((a,b) => a.name.localeCompare(b.name))
    .map(p => {
      const active = p.id === state.activePatientId;
      const badge = (Number(p.headlineAmount)||0) > 0 ? `<span class="ml-auto text-xs rounded-full bg-emerald-50 text-emerald-700 px-2 py-0.5">₹${Number(p.headlineAmount).toLocaleString('en-IN')}</span>` : '';
      return el(`<button class="w-full ${active ? 'bg-slate-100' : 'hover:bg-slate-50'} flex items-center gap-2 px-3 py-2 rounded-lg">
          <span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white text-sm">${p.name[0]?.toUpperCase()||'P'}</span>
          <span class="truncate text-left">${p.name}</span>
          ${badge}
        </button>`);
    });

  patientList.innerHTML = '';
  items.forEach((btn, idx) => {
    const p = state.patients.filter(pp => pp.name.toLowerCase().includes((patientSearch.value||'').toLowerCase())).sort((a,b) => a.name.localeCompare(b.name))[idx];
    btn.addEventListener('click', () => setActivePatient(p.id));
    patientList.appendChild(btn);
  });
}

addPatientForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = newPatientName.value.trim();
  if (!name) return;
  const patient = await api('/api/patients', { method: 'POST', body: JSON.stringify({ name }) });
  newPatientName.value = '';
  state.patients.push(patient);
  renderPatients();
  setActivePatient(patient.id);
});

patientSearch.addEventListener('input', renderPatients);

// --------------- Active patient / header ---------------
const activePatientName = document.getElementById('activePatientName');
const activePatientContact = document.getElementById('activePatientContact');
const headlineAmount = document.getElementById('headlineAmount');
const saveHeadline = document.getElementById('saveHeadline');

function setActivePatient(id) {
  state.activePatientId = id;
  const p = state.patients.find(x => x.id === id);
  activePatientName.textContent = p ? p.name : 'No patient selected';
  activePatientContact.textContent = p && p.contact ? p.contact : '';
  headlineAmount.value = p ? Number(p.headlineAmount||0) : 0;

  // Join chat room and load messages
  if (state.socket && p) {
    state.socket.emit('join', { patientId: p.id });
    loadMessages(p.id);
  }

  // Switch to chat tab (nice DX)
  showTab('chat');

  // Update appointment form preselect
  const sel = document.getElementById('apptPatient');
  if (sel && p) sel.value = p.id;

  renderPatients();
}

saveHeadline.addEventListener('click', async () => {
  const p = state.patients.find(x => x.id === state.activePatientId);
  if (!p) return;
  const amt = Number(headlineAmount.value) || 0;
  const updated = await api(`/api/patients/${p.id}`, { method: 'PATCH', body: JSON.stringify({ headlineAmount: amt }) });
  // Update local
  const idx = state.patients.findIndex(x => x.id === p.id);
  state.patients[idx] = updated;
  renderPatients();
  if (!document.getElementById('view-earnings').classList.contains('hidden')) {
    loadEarnings();
  }
});

// --------------- Tabs ---------------
const tabs = document.querySelectorAll('.tab-btn');
tabs.forEach(btn => btn.addEventListener('click', () => showTab(btn.dataset.tab)));

function showTab(tab) {
  document.getElementById('view-schedule').classList.toggle('hidden', tab !== 'schedule');
  document.getElementById('view-chat').classList.toggle('hidden', tab !== 'chat');
  document.getElementById('view-earnings').classList.toggle('hidden', tab !== 'earnings');

  tabs.forEach(b => {
    if (b.dataset.tab === tab) { b.classList.add('bg-slate-900','text-white'); }
    else { b.classList.remove('bg-slate-900','text-white'); }
  });

  if (tab === 'earnings') loadEarnings();
}

// --------------- Schedule ---------------
const addApptForm = document.getElementById('addApptForm');
const apptPatient = document.getElementById('apptPatient');
const apptDateTime = document.getElementById('apptDateTime');
const apptFee = document.getElementById('apptFee');
const apptDuration = document.getElementById('apptDuration');
const apptNotes = document.getElementById('apptNotes');
const apptList = document.getElementById('apptList');

function fillApptPatientSelect() {
  apptPatient.innerHTML = state.patients.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
  if (state.activePatientId) apptPatient.value = state.activePatientId;
}

addApptForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!apptPatient.value) { alert('Please add/select a patient'); return; }
  const payload = {
    patientId: apptPatient.value,
    dateTime: apptDateTime.value,
    fee: Number(apptFee.value)||0,
    duration: Number(apptDuration.value)||30,
    notes: apptNotes.value||''
  };
  const created = await api('/api/appointments', { method: 'POST', body: JSON.stringify(payload) });
  state.appointments.push(created);
  apptDateTime.value = '';
  apptFee.value = '';
  apptDuration.value = '30';
  apptNotes.value = '';
  renderAppointments();
  loadEarnings();
});

async function deleteAppt(id) {
  if (!confirm('Delete this appointment?')) return;
  await api(`/api/appointments/${id}`, { method: 'DELETE' });
  state.appointments = state.appointments.filter(a => a.id !== id);
  renderAppointments();
  loadEarnings();
}

function renderAppointments() {
  const rows = state.appointments
    .slice()
    .sort((a,b)=> new Date(a.dateTime)-new Date(b.dateTime))
    .map(a => {
      const p = state.patients.find(x => x.id === a.patientId);
      return el(`<div class="flex items-center gap-3 p-3 rounded-lg border hover:bg-slate-50">
        <div class="flex-1">
          <div class="font-medium">${p ? p.name : 'Unknown'} · ${formatDT(a.dateTime)}</div>
          <div class="text-xs text-slate-500">Duration ${a.duration} mins ${a.notes ? ' · ' + a.notes : ''}</div>
        </div>
        <div class="text-sm font-semibold">${rupees(a.fee)}</div>
        <button class="text-xs rounded-lg border px-2 py-1">Delete</button>
      </div>`);
    });

  apptList.innerHTML = '';
  rows.forEach((row, i) => {
    const appt = state.appointments.slice().sort((a,b)=> new Date(a.dateTime)-new Date(b.dateTime))[i];
    row.querySelector('button').addEventListener('click', () => deleteAppt(appt.id));
    apptList.appendChild(row);
  });
}

// --------------- Chat ---------------
const chatMessages = document.getElementById('chatMessages');
const chatForm = document.getElementById('chatForm');
const chatInput = document.getElementById('chatInput');

function renderMessages() {
  chatMessages.innerHTML = '';
  state.messages.sort((a,b)=> a.timestamp-b.timestamp).forEach(m => {
    const mine = m.sender === 'doctor';
    const bubble = el(`<div class="flex ${mine ? 'justify-end' : 'justify-start'}">
      <div class="max-w-[70%] rounded-2xl px-3 py-2 text-sm ${mine ? 'bg-slate-900 text-white' : 'bg-white border'}">
        <div>${m.text.replace(/</g,'&lt;')}</div>
        <div class="text-[10px] mt-1 opacity-60">${new Date(m.timestamp).toLocaleTimeString()}</div>
      </div>
    </div>`);
    chatMessages.appendChild(bubble);
  });
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

chatForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  const p = state.patients.find(x => x.id === state.activePatientId);
  if (!p) { alert('Select a patient first'); return; }
  state.socket.emit('message', { patientId: p.id, sender: 'doctor', text });
  chatInput.value = '';
});

// --------------- Earnings ---------------
// Charts state
let chartMonthly, chartByPatient;

// Helper to group by month
function groupByMonth(appts) {
  const map = new Map();
  for (const a of appts) {
    const d = new Date(a.dateTime);
    const key = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0');
    const fee = Number(a.fee)||0;
    map.set(key, (map.get(key)||0) + fee);
  }
  // sort keys ascending
  const keys = Array.from(map.keys()).sort();
  return { labels: keys, values: keys.map(k => map.get(k)) };
}

const earnFrom = document.getElementById('earnFrom');
const earnTo = document.getElementById('earnTo');
const applyRange = document.getElementById('applyRange');
const resetRange = document.getElementById('resetRange');

applyRange?.addEventListener('click', () => loadEarnings());
resetRange?.addEventListener('click', () => { earnFrom.value=''; earnTo.value=''; loadEarnings(); });

const totalAppt = document.getElementById('totalAppt');
const totalHeadline = document.getElementById('totalHeadline');
const totalCombined = document.getElementById('totalCombined');
const earningsTable = document.getElementById('earningsTable');
const exportCsv = document.getElementById('exportCsv');

async function loadEarnings() {
  const data = await api('/api/earnings/summary');
  totalAppt.textContent = rupees(data.totalFromAppointments);
  totalHeadline.textContent = rupees(data.headlineTotals);
  totalCombined.textContent = rupees(data.combined);

  const rows = Object.entries(data.byPatient).map(([pid, sum]) => {
    const p = state.patients.find(x => x.id === pid);
    return { name: p ? p.name : 'Unknown', amount: sum };
  }).sort((a,b)=> b.amount - a.amount);

  const table = el(`<div class="divide-y">
    <div class="grid grid-cols-2 text-xs text-slate-500 pb-2">
      <div>Patient</div><div class="text-right">Amount</div>
    </div>
  </div>`);
  rows.forEach(r => {
    table.appendChild(el(`<div class="grid grid-cols-2 py-2">
      <div>${r.name}</div><div class="text-right font-medium">${rupees(r.amount)}</div>
    </div>`));
  });
  earningsTable.innerHTML = '';
  earningsTable.appendChild(table);

  exportCsv.onclick = () => {
    const lines = [['Patient','Amount (INR)'], ...rows.map(r => [r.name, r.amount])];
    const csv = lines.map(line => line.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'earnings_by_patient.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };
}

// --------------- Init ---------------
function initSocket() {
  state.socket = io();
  state.socket.on('connect', () => {
    if (state.activePatientId) {
      state.socket.emit('join', { patientId: state.activePatientId });
    }
  });
  state.socket.on('message', (msg) => {
    if (msg.patientId === state.activePatientId) {
      state.messages.push(msg);
      renderMessages();
    }
  });
}

async function boot() {
  initSocket();
  await loadPatients();
  await loadAppointments();
}

boot();
