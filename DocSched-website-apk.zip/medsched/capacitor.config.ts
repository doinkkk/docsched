import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.docsched',
  appName: 'DocSched',
  webDir: 'public',
  server: {
    androidScheme: 'https',
    cleartext: true,
  }
};

export default config;
